package weathercenter;

public class Sensor {
	private String sensorId;
	private String passkey;
	
	public String getSensorId() {
		return sensorId;
	}
	
	public void setSensorId(String sensorId) {
		this.sensorId = sensorId;
	}
	
	public String getPasskey() {
		return passkey;
	}
	
	public void setPasskey(String passkey) {
		this.passkey = passkey;
	}
	
	
}

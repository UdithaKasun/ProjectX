package weathercenter;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;

public class WeatherServer {

	private String hostname ="localhost";
	private final static int PORT = 9001;
	private static Map<String,PrintWriter> sensorsMap = new HashMap<>();
	private static Map<String,Boolean> sensorsUpdateStatus = new HashMap<>();
	final static Logger logger = Logger.getLogger(WeatherServer.class);
	public static void main(String[] args) {
		logger.info("**** Server Startup ****");
        try {
			ServerSocket listener = new ServerSocket(PORT);
			logger.info("Server socket started at port : "+ PORT);
			logger.info("Server socket is now open for client connections");
			Thread t = new Thread(()->{
				try {
					while(true){
						ServerSocketThread clientHandler = new ServerSocketThread(listener.accept(), sensorsMap, sensorsUpdateStatus);
						clientHandler.start();
					}
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}
			});
			
			Thread t2 = new Thread(()->{
				while(true){
					try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("hello");
				}
			});
			t.start();
		
			
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}

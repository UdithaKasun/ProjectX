package weathercenter;

import java.io.IOException;
import java.io.StringWriter;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.quartz.CronScheduleBuilder;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.xml.sax.SAXException;

public class Utilities {

	private final static JSONParser parser = new JSONParser();

	//Get JSON Object Instance
	public static JSONObject getJSONObjectInstance() {
		return new JSONObject();
	}

	//Get JSON Object Instance given a JSON String
	public static JSONObject getJSONObjectInstance(String jsonString) {
		try {
			Object sourceObject = parser.parse(jsonString);
			JSONObject jsonObject = (JSONObject) sourceObject;
			return jsonObject;
		} catch (ParseException e) {
			return null;
		}

	}

	//Get JSON Value for specific key   
	public static String getValue(JSONObject source, String key) {
		return source.get(key).toString();
	}
	
	//Clear JSON Object Key Map 
	public static void clearJSONObjectInstance(JSONObject source) {
		source.clear();
	}

	//Put a Key Value Pair to JSON Object
	public static void putValue(JSONObject source, String key, Object Value) {
		source.put(key, Value);
	}

	//Get a JSON Object as JSON String 
	public static String getJSONAsString(JSONObject source) {
		StringWriter writer = new StringWriter();
		try {
			source.writeJSONString(writer);
			return writer.toString();
		} catch (IOException e) {
			return e.getMessage();
		}
	}

	//Schedule a Cron Job given a Cron Expression and Job Implementation
	public static void scheduleCronJob(String jobName, String triggerName, String cronExpression, Job scheduleJob)
			throws SchedulerException {
		// Create Cron Job
		JobDetail cronJob = JobBuilder.newJob(scheduleJob.getClass()).withIdentity(jobName).build();

		// Creating Cron Trigger
		Trigger cronTrigger = TriggerBuilder.newTrigger().withIdentity(triggerName)
				.withSchedule(CronScheduleBuilder.cronSchedule(cronExpression)).build();

		// schedule it
		Scheduler scheduler;
		try {
			scheduler = new StdSchedulerFactory().getScheduler();
			scheduler.start();

			scheduler.scheduleJob(cronJob, cronTrigger);
		} catch (SchedulerException e) {
			throw e;
		}
	}

	public List<JSONObject> readXmlElementsAsList(String xmlSource, String nodeName, String[] elementList) {
		SAXParserFactory parserFactor = SAXParserFactory.newInstance();
		SAXParser parser;
		try {
			parser = parserFactor.newSAXParser();
			SAXHandler handler = new SAXHandler(nodeName, elementList);
			parser.parse(ClassLoader.getSystemResourceAsStream(xmlSource), handler);
			return handler.getItemList();
		} catch (ParserConfigurationException e) {
			return null;
		} catch (SAXException e) {
			return null;
		} catch (IOException e) {
			return null;
		}

	}

}

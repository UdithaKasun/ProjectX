package weathercenter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Map;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

public class ServerSocketThread extends Thread{
	private String sensorId;
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private Map<String,PrintWriter> sensorWriter;
    private JSONObject jsonInput;
    private Map<String,Boolean> sensorStatusMap;
    final static Logger logger = Logger.getLogger(ServerSocketThread.class);
    private boolean loggedStatus = false;
    public ServerSocketThread(Socket sourceSocket,Map<String,PrintWriter> sensorWriter,Map<String,Boolean> statusMap){
    	this.socket = sourceSocket;
    	this.sensorWriter = sensorWriter;
    	this.sensorStatusMap = statusMap;
    }
    
    public void run() {
    	while(true)
    	{
    		logger.info("Socket Connection Initiated with client - " +socket.getLocalAddress().getHostName() + ":" + socket.getPort());
    		manageClients();
    		break;
    	}
       
    }
    
    private boolean authenticateUser(String id, String passkey){
    	if(id.equals("admin") && passkey.equals("admin"))
    		return true;
    	else
    		return false;
    }
    
	private void manageClients() {
		try {

			// Create character streams for the socket.
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new PrintWriter(socket.getOutputStream(), true);

			// Authentication of Sensor
			while (true) {
				logger.info("Authentication Started for client - " + socket.getLocalAddress().getHostName() + ":"
						+ socket.getPort());

				while (!loggedStatus) {
					jsonInput = Utilities.getJSONObjectInstance(in.readLine());
					sensorId = Utilities.getValue(jsonInput, "username");
					String password = Utilities.getValue(jsonInput, "password");
					if (sensorId == null) {
						return;
					}
					
					if(authenticateUser(sensorId, password)){
						out.println("AUTHENTICATED");
						synchronized (sensorWriter) {
							if (!sensorWriter.containsKey(sensorId)) {
								sensorWriter.put(sensorId, out);
								logger.info("Authentication Success for client - " + socket.getLocalAddress().getHostName() + ":"
										+ socket.getPort());
								loggedStatus = true;
								break;
							}
						}
					}
					else{
						out.println("FAILED");
						logger.warn("Authentication Failed for client - " + socket.getLocalAddress().getHostName() + ":"
								+ socket.getPort());
					}
				}
				
				// Accept messages from this client and broadcast them.
				// Ignore other clients that cannot be broadcasted to.
				while (true) {
//					String update = in.readLine();
//					System.out.println(update);
				}
			}
		} catch (IOException e) {
			logger.error("Exception Ocurred : ", e);
		} finally {
			// Sensor is going offline
			logger.info("Cient Disconnected - " + socket.getLocalAddress().getHostName() + ":"
					+ socket.getPort());
			if (sensorId != null) {
				sensorWriter.remove(sensorId);
			}
			try {
				socket.close();
				return;
			} catch (IOException e) {
				logger.error("Exception for Client " + socket.getLocalAddress().getHostName() + ":"
						+ socket.getPort() + e);
			}
		}
	}
}

package weathercenter;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXHandler extends DefaultHandler {

	private List<JSONObject> itemList = new ArrayList<>();
	JSONObject item = null;
	String content = null;
	private String parentNode;
	private String[] childNodeElements;

	public SAXHandler(String parentNode, String[] childNodeElements) {
		this.parentNode = parentNode;
		this.childNodeElements = childNodeElements;
	}

	public List<JSONObject> getItemList() {
		return itemList;
	}

	@Override
	// Triggered when the start of tag is found.
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		// Create a new JSON Object when a parent node is reached
		if (qName.equals(parentNode)) {
			item = new JSONObject();
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equals(parentNode)) {
			itemList.add(item);
		}

		for (String childNode : childNodeElements) {
			if (qName.equals(childNode)) {
				item.put(childNode, content);
			}
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		content = String.copyValueOf(ch, start, length).trim();
	}

}

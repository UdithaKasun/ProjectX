package weathercenter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import org.json.simple.JSONObject;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ClientLoginController implements Initializable{
	@FXML
	private ImageView imageLogo;

	@FXML
	private TextField tfSensorId;

	@FXML
	private PasswordField tfPasskey;

	@FXML
	private Button btnAuthenticate;

	
	// Create Socket Instance with host name and port number
	Socket clientSocket;

	// Get PrintWrter of socket
	// This is used to write data to socket
	PrintWriter socketOut;

	// Get BufferedReader of socket
	// This is used to read data from socket
	BufferedReader socketIn; 
	
	//Message recieved from Server
	String serverMessage;
	
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		String hostname = "localhost";
		int port = 9001;
		try {
			
			// Create Socket Instance with host name and port number
			clientSocket = new Socket(hostname, port);
			
			// Get PrintWrter of socket
			// This is used to write data to socket
			socketOut = new PrintWriter(clientSocket.getOutputStream(), true);

			// Get BufferedReader of socket
			// This is used to read data from socket
			socketIn = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); 

		
		} catch (UnknownHostException e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Sensor Emulator");
			alert.setHeaderText("Connection Error");
			alert.setContentText(e.getLocalizedMessage());
			alert.showAndWait();
			System.exit(-1);
		} catch (IOException e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Sensor Emulator");
			alert.setHeaderText("Connection Error");
			alert.setContentText(e.getLocalizedMessage());
			alert.showAndWait();
			System.exit(-1);
		}


	}

	@FXML
	private void Authenticate() {
		JSONObject userDetails = Utilities.getJSONObjectInstance();
		Utilities.putValue(userDetails, "username", tfSensorId.getText());
		Utilities.putValue(userDetails, "password", tfPasskey.getText());
		socketOut.println(Utilities.getJSONAsString(userDetails));
		try {
			String serverResponse = socketIn.readLine();
			if(serverResponse.equals("FAILED")){
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("Sensor Emulator");
				alert.setHeaderText("Authentication Failed");
				alert.setContentText("Sensor Id or Passkey is incorrect.");
				alert.showAndWait();
			}
		} catch (IOException e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Sensor Emulator");
			alert.setHeaderText("Connection Error");
			alert.setContentText(e.getLocalizedMessage());
			alert.showAndWait();
			System.exit(-1);
		}
	}

}	
	


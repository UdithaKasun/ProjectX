package weathercenter;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.util.Map;
import org.apache.log4j.Logger;

public class ConnectionInitiator extends Thread{
	final static Logger logger = Logger.getLogger(WeatherServer.class);
	public ConnectionInitiator(ServerSocket serverSocket,Map<String,PrintWriter> sensorWritersMap,Map<String,Boolean> sensorStatusMap) throws IOException{
		while(true){
			logger.info("Waiting for Client Requests...");
			ServerSocketThread clientHandler = new ServerSocketThread(serverSocket.accept(), sensorWritersMap, sensorStatusMap);
			clientHandler.start();
		}
	}
}
